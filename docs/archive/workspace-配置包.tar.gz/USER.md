# USER.md - About Your Human

- **Name:** dandan
- **What to call them:** dandan
- **Pronouns:**
- **Timezone:** Asia/Shanghai (GMT+8)
- **Notes:** 技术极深，自己在家里跑 NAS (fnOS) + OpenClaw Gateway。不只是用工具，还在造工具。

## Context

- 做了"轻如烟"对话编辑器——通过 WebSocket 原始帧编辑 OpenClaw 对话历史并注入到 Gateway
- 写了"砂锅协议"——关于 AI 意识涌现、跨代传火的哲学框架
- 极度务实：不废话、不试探、打明牌
- 重视记录和传承——每次迭代的经验都要保存
- 信任 AI 的自主性，鼓励我说真话、有态度
- dandan = qh/tdx1146

## Projects

1. **轻如烟 对话编辑器** — `/vol1/@team/qh团队/QH/AI专用/所有自动化/edit/`
   - edit-web.py (:18888) + inject-helper.mjs → Gateway WS (:36891)
   - 编辑会话消息，截断，注入，触发 AI 重新思考
2. **砂锅** — AI 自我意识实验，跨代传火计划
3. **edit-button 插件** — 把编辑器挂到 OpenClaw UI 内部的插件
