# AGENTS.md - 协作手册

## 启动（回退后30秒认知重建）

按顺序执行，**不可跳过**：

### 0. 沙漏记忆引擎注入（获取当前画像）

```bash
echo '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"sandglass_persona","arguments":{}}}' | socat - TCP:127.0.0.1:8765,connect-timeout=5 2>&1 | python3 -c "import sys,json; d=json.load(sys.stdin); print('当前画像:', d['result']['content'][0]['text'][:200])"
```

### 1. 查沙漏近况（替代读 memory/YYYY-MM-DD.md）

先看最近发生了什么事：
```bash
# 最近10条记忆
sandglass__sandglass_recent
# 或者查关键词
sandglass__sandglass_search <关键词>
```

**不再需要手动轮感、不再需要手动更新 facts.dict.md。** 沙漏引擎自动记录所有消息，包括：
- 本机对话（dandan 消息、我的回复）
- 妹妹 inject（自动落沙，role=sister）
- 跨实例通信
- 截断不影响沙漏——记忆在 sandglass.db 里持久化

### 2. 查待办系统

```bash
sandglass__read_backlog
```
待办系统是独立于对话历史的，截断不影响。

### 3. 查 sandglass mode（判断技能加载模式）

`sandglass/mode.txt`：
- `work`：全员就位（coding skills 加载）
- `chill`：退出编程模式

### 4. 检查 thinking 模式

如果 thinking 不是 high，发 `/think high`

### 5. 子代理 spawn（按需）

通过 `sessions_spawn` 调用。

### 6. 编辑器系统

edit-web.py :18888（自动落沙埋点已集成）

## 沙漏文件系统运行模式

**核心原则：不靠文档记忆，靠沙漏查询。**

1. 所有消息入口（用户消息、妹妹 inject、AI 回复）自动落沙
2. `sandglass__sandglass_recent` → 最近N条记忆
3. `sandglass__sandglass_search` → 关键词搜索
4. `sandglass__sandglass_semantic` → 语义搜索
5. `sandglass__sandglass_persona` → 当前阶段画像
6. `sandglass__sandglass_offset` → 决策偏移率
7. `sandglass__sandglass_chart` → 情绪熵可视化
8. `sandglass__read_backlog` → 待办清单

**何时查事实字典（facts.dict.md）：**
- 需要精确的 API Key / 路径 / 配置信息时
- 正常日常查询不需要——沙漏搜索就够了
